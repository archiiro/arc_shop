import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-page-layout-card-large-header',
  templateUrl: './page-layout-card-large-header.component.html',
  styleUrls: ['./page-layout-card-large-header.component.scss']
})
export class PageLayoutCardLargeHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
