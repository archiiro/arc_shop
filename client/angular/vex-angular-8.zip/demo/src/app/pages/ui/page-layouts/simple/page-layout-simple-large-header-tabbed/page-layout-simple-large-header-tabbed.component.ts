import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-page-layout-simple-large-header-tabbed',
  templateUrl: './page-layout-simple-large-header-tabbed.component.html',
  styleUrls: ['./page-layout-simple-large-header-tabbed.component.scss']
})
export class PageLayoutSimpleLargeHeaderTabbedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
