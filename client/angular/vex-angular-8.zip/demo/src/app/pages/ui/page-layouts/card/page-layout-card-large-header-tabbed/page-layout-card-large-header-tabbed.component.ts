import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-page-layout-card-large-header-tabbed',
  templateUrl: './page-layout-card-large-header-tabbed.component.html',
  styleUrls: ['./page-layout-card-large-header-tabbed.component.scss']
})
export class PageLayoutCardLargeHeaderTabbedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
