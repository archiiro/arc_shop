import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-page-layout-card',
  templateUrl: './page-layout-card.component.html',
  styleUrls: ['./page-layout-card.component.scss']
})
export class PageLayoutCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
