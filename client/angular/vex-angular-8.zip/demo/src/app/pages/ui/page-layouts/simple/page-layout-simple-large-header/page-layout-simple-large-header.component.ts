import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-page-layout-simple-large-header',
  templateUrl: './page-layout-simple-large-header.component.html',
  styleUrls: ['./page-layout-simple-large-header.component.scss']
})
export class PageLayoutSimpleLargeHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
