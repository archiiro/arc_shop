import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-help-center-pricing',
  templateUrl: './help-center-pricing.component.html',
  styleUrls: ['./help-center-pricing.component.scss']
})
export class HelpCenterPricingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
