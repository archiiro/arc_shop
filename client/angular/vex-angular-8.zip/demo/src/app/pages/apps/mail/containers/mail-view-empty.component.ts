import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-mail-view-empty',
  templateUrl: './mail-view-empty.component.html',
  styleUrls: ['./mail-view-empty.component.scss']
})
export class MailViewEmptyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
