export interface ScrumboardLabel {
  label: string;
  bgClass: string;
  textClass: string;
}
