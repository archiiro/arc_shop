import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-help-center-getting-started',
  templateUrl: './help-center-getting-started.component.html',
  styleUrls: ['./help-center-getting-started.component.scss']
})
export class HelpCenterGettingStartedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
